package com.nova.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.app.Activity
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingLang: String? = null
    private var retries = 0
    private var lastLang = "hi-IN"

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "NovaNative")
        tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { js("nv.spStart()") }
            override fun onDone(id: String?) { js("nv.spEnd()") }
            @Deprecated("") override fun onError(id: String?) { js("nv.spEnd()") }
        })
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun startListening(lang: String, isRetry: Boolean = false) {
        lastLang = lang
        if (!isRetry) retries = 0
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("nv.error('Speech service नहीं मिली (Google app इंस्टॉल करें)')"); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            js("nv.error('माइक की permission दें, फिर दोबारा दबाएं')"); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { js("nv.start()") }
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    js("nv.end()")
                    if (t != null) js("nv.result(" + JSONObject.quote(t) + ")")
                }
                override fun onError(e: Int) {
                    js("nv.end()")
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) return
                    // 11 = server disconnected, 5 = client, 8 = busy, 1/2 = network
                    if (e in intArrayOf(11, 5, 8, 1, 2, 3, 4) && retries < 2) {
                        retries++
                        runOnUiThread {
                            recognizer?.destroy(); recognizer = null
                            web.postDelayed({ startListening(lastLang, true) }, 500)
                        }
                        return
                    }
                    if (e in intArrayOf(11, 5, 8, 1, 2, 3, 4, 12, 13)) { launchSystemVoice(lastLang); return }
                    js("nv.error('code $e')")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            })
        }
    }

    private fun launchSystemVoice(lang: String) {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए…")
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, 77)
        } catch (e: Exception) {
            js("nv.error('Google voice नहीं मिला। Google app इंस्टॉल/अपडेट करें')")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) js("nv.result(" + JSONObject.quote(t) + ")")
        }
    }

    inner class Bridge {
        @JavascriptInterface fun listen(lang: String) = runOnUiThread { startListening(lang) }
        @JavascriptInterface fun stopListen() = runOnUiThread { recognizer?.stopListening() }
        @JavascriptInterface fun speak(text: String, lang: String) = runOnUiThread {
            if (!ttsReady) { js("nv.spEnd()"); return@runOnUiThread }
            tts?.language = Locale.forLanguageTag(lang)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
        @JavascriptInterface fun stopSpeak() = runOnUiThread { tts?.stop() }
        @JavascriptInterface fun openUrl(url: String) = runOnUiThread {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
        }
    }

    override fun onDestroy() { recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}
